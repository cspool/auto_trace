# Workflow05 R10 trace visualization and evidence report

Presentation version: `workflow05-r10-replay001-trace-visualization-reporting-v3`  
Runtime goal: `R10`  
Selected backend: `custom_plotly_timeline_fallback`  
Analytical values recomputed: `false`

## Evidence and clock boundary

- Historical parent: `pra2026-bh408@3d036144-qwen35-row0-greedy32-warmup1-eager-aiterua-dcu1` (`3fa361bc26577bc5e67def9c8f35fb16b1479c8b78c0989bd0e252989c227ffe`), planning/estimate only.
- Current child: `pra2026-bh408@3d036144-qwen35-row0-greedy32-warmup1-eager-aiterua-dcu1/workflow05-current@0abe1e1d-2d523f7f` (`dec9864969ca313f559f9bd576b4f81a33b25319f29457a3ef3c436876527bd1`), selective non-replay observation only.
- Relation: `same_request_cross_revision`; clocks are not mergeable and parent timing is never current observed timing.
- Evidence vocabulary: `observed`, `inferred`, `estimate`, `replay_projected`, `heuristic`, `unavailable`.
- Hardware counter semantics: `replay_projected_step`; PMC replay timing used as latency: `false`.

## Trace delivery

All nine bounded windows were exported as native PFTrace first and native Chrome JSON with one exact same-DB HIPTX marker second. The captured database hash was unchanged, disposable-copy mutation was limited to `RANGE_SUMMARY`, and no model/GPU capture occurred.

Official interface attempts on the selected normalized trace:

- `perfetto_trace_processor_python_api`: `unavailable` — module discovery failed: No module named 'perfetto'
- `perfetto_trace_processor_cli`: `unavailable` — no trace_processor or trace_processor_shell on PATH
- `perfetto_ui_local_file`: `candidate_unvalidated` — no official local parser completed; retain trace for later UI attempt

The normalized Chrome trace remains Perfetto-compatible and the thin localhost HTTP PING/PONG + `postMessage(ArrayBuffer)` launcher is delivered, but no official parse or browser handshake was completed in this runtime. The Plotly pages are visibly labeled **CUSTOM FALLBACK** and are not represented as Perfetto parses or raw-trace viewers.

## Coverage and risk (copied from P10)

- `historical_semantic_group_coverage`: `88.966936708467%` — historical planned semantic-group coverage; not current whole-request latency coverage
- `historical_exact_current_selected_latency_coverage`: `0.113627642003%` — historical mass linked to current measurements without calibration transfer
- `current_selected_hardware_family_coverage`: `14.305290461508%` — selected-family duration coverage, not request latency coverage
- `high_risk_unsampled_estimate_mass`: `59.779082522591%` — historical high-risk unsampled estimate mass; not current observed latency
- `current_selected_strict_owner_coverage`: `100.000000000000%` — observed selected process kernel duration with strict same-DB ownership

- Historical high-risk unsampled estimate mass: `7223.028930619631 ms` / `0.597790825226` of the historical denominator. This is not current observed latency.
- Current hardware deferred families: `8` rows / `2.801600000000 ms` of selected non-replay family duration.
- Unknown dependency edges: `23`; longest-path runs: `0`; critical path: `unavailable_no_fully_evidenced_current_timed_component`.
- Candidate-only concurrency rows: `536`; confirmed rows: `0`; speedup claim emitted: `false`.
- Counter-level low-utilization threshold: `unavailable` — the supplied Workflow05 controls contain no current counter-level utilization-classification threshold.

## Supplied long/gap candidates (no R10 recomputation)

Source: `R08/long_process_windows.csv`; timing meanings remain separate and are not summed.

| Selection rank | Event | Stage | Observed host ms | Strict-owned busy union ms | Supplied hardware finding | Critical path |
|---:|---|---|---:|---:|---|---|
| 1 | `input1_layer7` | `qkv_projection` | `1.622279` | `2.31216` | `["No current-child hardware conclusion is available for this exact P08 window; all measured families were deferred below the marginal evidence threshold and R4 remains historical planning context only."]` | `unavailable` |
| 2 | `input11_layer33` | `gdn_gated_rmsnorm` | `0.792224` | `0.00352` | `["No current-child hardware conclusion is available for this exact P08 window; all measured families were deferred below the marginal evidence threshold and R4 remains historical planning context only."]` | `unavailable` |
| 3 | `input11_layer19` | `mlp` | `1.160566` | `0.39248` | `["No current-child hardware conclusion is available for this exact P08 window; all measured families were deferred below the marginal evidence threshold and R4 remains historical planning context only."]` | `unavailable` |
| 4 | `input6_layer0` | `output_projection.part01_mixer_out_proj` | `0.489272` | `0.08912` | `["No current-child hardware conclusion is available for this exact P08 window; all measured families were deferred below the marginal evidence threshold and R4 remains historical planning context only."]` | `unavailable` |
| 5 | `input2_layer50` | `input_rmsnorm` | `0.536783` | `0.14112` | `["No dominant resource cause is established by the available replay_projected diagnostics on selected non-replay interval [1785989426701360541,1785989426701501661] ns.","No causal process-level bottleneck or speedup is claimed; the attached values are offline replay_projected family diagnostics."]` | `unavailable` |
| 6 | `input17_layer0` | `qkv_projection` | `0.852965` | `0.12096` | `["No dominant resource cause is established by the available replay_projected diagnostics on selected non-replay interval [1785989436342505525,1785989436342928565] ns.","No causal process-level bottleneck or speedup is claimed; the attached values are offline replay_projected family diagnostics."]` | `unavailable` |
| 7 | `input24_layer11` | `qkv_projection` | `1.559539` | `0.12384` | `["No dominant resource cause is established by the available replay_projected diagnostics on selected non-replay interval [1785989439819246110,1785989439819348350] ns.","processed_ALU diagnostic proxy 0.098623091056 pct is below recorded historical R4 q25 threshold 0.234823000000 pct when replay_projected onto selected non-replay family interval [1785989439819522750,1785989439820496670] ns; this is a low-activity proxy, not a causal utilization finding","No causal process-level bottleneck or speedup is claimed; the attached values are offline replay_projected family diagnostics."]` | `unavailable` |
| 8 | `input18_layer51` | `rope` | `1.134466` | `0.03264` | `["processed_ALU diagnostic proxy 0.002548633100 pct is below recorded historical R4 q25 threshold 0.234823000000 pct when replay_projected onto selected non-replay family interval [1785989437201606776,1785989437201901815] ns; this is a low-activity proxy, not a causal utilization finding","processed_ALU diagnostic proxy 0.134724085100 pct is below recorded historical R4 q25 threshold 0.234823000000 pct when replay_projected onto selected non-replay family interval [1785989437202153815,1785989437202170135] ns; this is a low-activity proxy, not a causal utilization finding","No dominant process-level cause is established because current targeted hardware covers only a subset of the exact P08 kernel-family denominator."]` | `unavailable` |
| 9 | `input13_layer10` | `output_projection.part01_mixer_out_proj` | `0.600073` | `0.05344` | `["No dominant resource cause is established by the available replay_projected diagnostics on selected non-replay interval [1785989433997065136,1785989433997118576] ns.","No causal process-level bottleneck or speedup is claimed; the attached values are offline replay_projected family diagnostics."]` | `unavailable` |

The concurrency file has no separate opportunity-rank field. Its 536 source-ordered rows remain candidate-only in the HTML, with all seven gates and their evidence JSON visible; R10 does not invent a rank or movement result.

## Immutable machine sources

- `/public/home/tangyu408/Qwen_DCU_Worker_0/perf_trace/runtime/workflow05-existing-evidence/workflow05-v4-dcu1-20260805/artifacts/R06/full_layer_process_overview.csv` — SHA-256 `ff13d5189083c5ece00810077458148e652926ccdeddcdf94b84c3402f1c35cb`
- `/public/home/tangyu408/Qwen_DCU_Worker_0/perf_trace/runtime/workflow05-existing-evidence/workflow05-v4-dcu1-20260805/artifacts/R06/workflow05_trace_index.csv` — SHA-256 `1e94f2a56af085232cfd12f61d19c0ccfe48a79cc2a39ea868e44f052b8c1cbc`
- `/public/home/tangyu408/Qwen_DCU_Worker_0/perf_trace/runtime/workflow05-existing-evidence/workflow05-v4-dcu1-20260805/artifacts/R07/replay-001/normalized/selected_process_performance.csv` — SHA-256 `55c4a2e3252cce3dc7c041f33209c7773c23b6b75ddd9ea74efb5119773adb57`
- `/public/home/tangyu408/Qwen_DCU_Worker_0/perf_trace/runtime/workflow05-existing-evidence/workflow05-v4-dcu1-20260805/artifacts/R07/replay-001/normalized/selected_process_gpu_timeline.csv` — SHA-256 `6d8b70ade372e2412b267946cc8e46ea610f80de367ce6199d7d5fa44447dc9a`
- `/public/home/tangyu408/Qwen_DCU_Worker_0/perf_trace/runtime/workflow05-existing-evidence/workflow05-v4-dcu1-20260805/artifacts/R08/replay-001/long_process_windows.csv` — SHA-256 `2a0fcafc1882de96c8d87d2c29c5ada2e9e334732b4ec538e110f4d2c32845c7`
- `/public/home/tangyu408/Qwen_DCU_Worker_0/perf_trace/runtime/workflow05-existing-evidence/workflow05-v4-dcu1-20260805/artifacts/R08/replay-001/targeted_hardware_metrics_by_kernel_family.csv` — SHA-256 `5b753e1e42c6fa8aac0c9d41bc54e9c510adf0b94b8b54cd5ded134affca36cb`
- `/public/home/tangyu408/Qwen_DCU_Worker_0/perf_trace/runtime/workflow05-existing-evidence/workflow05-v4-dcu1-20260805/artifacts/R09/replay-001/hardware_time_intervals.csv` — SHA-256 `85bba4c4bbd38d4f8c49d2c1297c30d523e2f6a6cba1fb3c3e85d1a2d04e2b18`
- `/public/home/tangyu408/Qwen_DCU_Worker_0/perf_trace/runtime/workflow05-existing-evidence/workflow05-v4-dcu1-20260805/artifacts/R09/replay-001/low_utilization_windows.csv` — SHA-256 `94792b91e33914d525bb37c3b5d03bd6d45e7c6194fde93752739cc0d6969373`
- `/public/home/tangyu408/Qwen_DCU_Worker_0/perf_trace/runtime/workflow05-existing-evidence/workflow05-v4-dcu1-20260805/artifacts/R09/replay-001/process_dependency_readiness.csv` — SHA-256 `05773ae4edc53395f86700467edb8ef795d544547044a4b4257138862c23cdb1`
- `/public/home/tangyu408/Qwen_DCU_Worker_0/perf_trace/runtime/workflow05-existing-evidence/workflow05-v4-dcu1-20260805/artifacts/R09/replay-001/concurrency_opportunities.csv` — SHA-256 `329c304cb8b94b48575e3f5fc7731a42bda85d0d3bd1a62987c457351f187e14`
- `/public/home/tangyu408/Qwen_DCU_Worker_0/perf_trace/runtime/workflow05-existing-evidence/workflow05-v4-dcu1-20260805/artifacts/R09/replay-001/workflow05_coverage_and_risk.json` — SHA-256 `e9ee21fb49aee7d9755e36c863f702504560ee21a2e2dc4391c35759887700c7`
- `/public/home/tangyu408/Qwen_DCU_Worker_0/perf_trace/runtime/workflow05-existing-evidence/workflow05-v4-dcu1-20260805/artifacts/R10/replay-001/workflow05_open_source_trace_attempts.json` — SHA-256 `28cc16e83ad38e6f7304ce8cd845685d613214e752f8f78bf652dd2d85a544ee`

## Terminal stop state

- Decision: `stop_current_r08_pmc_and_reenter_r07_only_if_the_next_selective_trace_batch_is_newly_authorized`.
- Escalation: `record next R07 batch but do not execute without new authorization`.
- New capture batch authorized/executed by R09: `false`.
- Current R08 family stop: `input11_layer19` / `mlp` / `reduction_softmax`, expected-evidence fraction `0.004033786381` below minimum `0.005`.
- Recorded next R07 batch, not authorized by R10: `input5_layer6` / `qkv_projection`, exact range `pra.fx_process.input5_layer6.qkv_projection`, expected-evidence fraction `0.101746168337`; reason: high-risk unsampled historical estimate weight remains material and calibration is non-transferable; a newly authorized exact batch is required.

R10 reproduces that terminal decision and stops. It does not invoke another skill, authorize a batch, run an optimization, or add a speedup claim.

## Entry points

- [Global 29×64 overview](E2E_PROCESS_ESTIMATE_AND_EVIDENCE.html)
- [Selected process trace](SELECTED_PROCESS_TRACE.html)
- [Long process analysis](LONG_PROCESS_WINDOW_ANALYSIS.html)
- [Utilization and concurrency candidates](LOW_UTILIZATION_AND_CONCURRENCY_OPPORTUNITIES.html)
- [Thin Perfetto UI launcher](PERFETTO_UI_LAUNCHER.html)
- [Open-source attempt manifest](workflow05_open_source_trace_attempts.json)
- [Native export manifest](workflow05_native_hipprof_window_exports.json)
- [Perfetto delivery manifest](perfetto_manifest.json)

## Unavailable mode extensions

- Official Perfetto Python parse/query: unavailable.
- Advertised Trace Processor CLI parse/query: unavailable.
- Browser PING/PONG, ArrayBuffer transfer, and UI parse: pending external browser interaction and therefore unvalidated.
- TrackEvent conversion, child-trace merge/bundle, overlay PFTrace parse, and P10 Trace Processor SQL: unavailable/not produced; no synthetic substitute was created.
- P10 used its verified normalized-table interval implementation, so `workflow05_gap_metrics.sql` and `workflow05_gap_metrics.csv` are intentionally absent.
